const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
require('dotenv').config();

const app = express();

// Middleware
app.use(cors({
  origin: process.env.CLIENT_URL || 'http://localhost:5173',
  credentials: true
}));
// app.use(express.json());
// Quick fix for Submission
app.use(cors()); // Allow ALL origins
app.use(express.json());


// Routes
app.use('/api/auth', require('./routes/auth'));
app.use('/api/products', require('./routes/products'));
app.use('/api/prices', require('./routes/prices'));
app.use('/api/wishlist', require('./routes/wishlist'));
app.use('/api/rewards', require('./routes/rewards'));
app.use('/api/admin', require('./routes/admin'));
app.use('/api/engine', require('./routes/engine'));

// Health check
app.get('/api/health', (req, res) => res.json({ status: 'ok', message: 'PricePulse API running' }));

// Start server even if MongoDB is not connected
const PORT = process.env.PORT || 5000;

mongoose.connect(process.env.MONGO_URI)
  .then(() => {
    console.log('✅ MongoDB connected');
  })
  .catch(err => {
    console.error('⚠️  Database Error (Resilient Mode Active):', err.message);
  });

app.listen(PORT, () => console.log(`🚀 Resilient Engine running on port ${PORT}`));
